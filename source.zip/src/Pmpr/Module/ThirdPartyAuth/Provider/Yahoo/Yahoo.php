<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b1cd01eb9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider\Yahoo; use Pmpr\Module\ThirdPartyAuth\Provider\Common; class Yahoo extends Common { public function __construct() { $this->name = self::oowokkckywyoauyu; $this->api = API::symcgieuakksimmu($this->aakmagwggmkoiiyu()); parent::__construct(); } }
