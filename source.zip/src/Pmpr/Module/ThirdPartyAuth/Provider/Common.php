<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f23967e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider; use Pmpr\Module\ThirdPartyAuth\Container; abstract class Common extends Container { protected ?API $api = null; protected ?string $name = null; public function auamgqiwisysomsa() : ?API { return $this->api; } public function aakmagwggmkoiiyu() : ?string { return $this->name; } public function gesoiqwieuaqaaqw() : string { $gqusacuooiagkuom = $this->uwkmaywceaaaigwo()->giiecckwoyiawoyy(); return $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([self::ugqacsomqcgmoqug => self::asiscgcuqkseseew, self::wssmqksaywiuskki => $this->aakmagwggmkoiiyu(), self::gcouqeuuoimiuqoc => $gqusacuooiagkuom->ikkqcccaweckukug(self::wqcswcwygsiiauqw)], $gqusacuooiagkuom->ieokeoyugcmwuumq()); } }
