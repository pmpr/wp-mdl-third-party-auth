<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             680106a435142             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider\Google; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\ThirdPartyAuth\Provider\Common; class Google extends Common { public function __construct() { $this->name = Constants::umookyimwkqqkieq; $this->api = API::symcgieuakksimmu($this->aakmagwggmkoiiyu()); parent::__construct(); } }
