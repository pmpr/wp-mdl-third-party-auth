<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c83fc37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider\Google; use Pmpr\Module\ThirdPartyAuth\Provider\Common; class Google extends Common { public function __construct() { $this->name = self::umookyimwkqqkieq; $this->api = API::symcgieuakksimmu($this->aakmagwggmkoiiyu()); parent::__construct(); } }
