<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f23967e5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Provider\Google; use Pmpr\Module\ThirdPartyAuth\Provider\Common; class Google extends Common { public function __construct() { $this->name = self::umookyimwkqqkieq; $this->api = API::symcgieuakksimmu($this->aakmagwggmkoiiyu()); parent::__construct(); } }
