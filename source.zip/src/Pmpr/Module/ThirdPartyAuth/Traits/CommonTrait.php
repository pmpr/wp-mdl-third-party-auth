<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c83fc37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto kuicqywysciceggs; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([self::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto mkwskuycuyguqqok; kuicqywysciceggs: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . self::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; mkwskuycuyguqqok: return $iewmcsieaqyamggu; } }
