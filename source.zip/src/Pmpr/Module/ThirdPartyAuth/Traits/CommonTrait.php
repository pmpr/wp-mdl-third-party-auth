<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6606b1cd01eb9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto cecuyayqoioasumi; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([self::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto qiaqsassksqiuyae; cecuyayqoioasumi: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . self::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; qiaqsassksqiuyae: return $iewmcsieaqyamggu; } }
