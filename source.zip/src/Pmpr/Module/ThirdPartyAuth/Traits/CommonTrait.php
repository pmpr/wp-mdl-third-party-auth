<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012947df3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto qgoiooayqmqqsiok; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([self::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto qwigomakwmyiwkgo; qgoiooayqmqqsiok: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . self::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; qwigomakwmyiwkgo: return $iewmcsieaqyamggu; } }
