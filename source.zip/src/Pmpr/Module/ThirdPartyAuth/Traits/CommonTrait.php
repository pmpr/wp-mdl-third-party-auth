<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11de8df45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; use Pmpr\Module\ThirdPartyAuth\Provider\Provider; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto mosqsmqimqgqoase; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([Provider::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto omugkkesagcyagmk; mosqsmqimqgqoase: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . Provider::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; omugkkesagcyagmk: return $iewmcsieaqyamggu; } }
