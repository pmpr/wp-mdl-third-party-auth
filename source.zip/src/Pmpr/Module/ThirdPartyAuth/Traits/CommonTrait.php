<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ae4eb0a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; use Pmpr\Module\ThirdPartyAuth\Provider\Provider; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto ssoucoucsgccekwe; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([Provider::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto qkcyqocqqwmqgqww; ssoucoucsgccekwe: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . Provider::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; qkcyqocqqwmqgqww: return $iewmcsieaqyamggu; } }
