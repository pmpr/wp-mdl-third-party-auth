<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e425c4d19f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Traits; trait CommonTrait { public function ggmimqeymoegueqg(string $iwigiqwyskocowwo) : string { $ieokeoyugcmwuumq = trailingslashit($this->uwkmaywceaaaigwo()->giiecckwoyiawoyy()->ieokeoyugcmwuumq()); if ($this->caokeucsksukesyo()->eiwcuqigayigimak()->ewswusimyeosaogm()) { goto eegqyykygiccaoeo; } $iewmcsieaqyamggu = $this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->yqymaqmqiqmmmsoo([self::cuwqkowuwgeysoqm => $iwigiqwyskocowwo], $ieokeoyugcmwuumq); goto ywqgcegomwaiuquc; eegqyykygiccaoeo: $iewmcsieaqyamggu = trailingslashit($ieokeoyugcmwuumq . self::cuwqkowuwgeysoqm) . $iwigiqwyskocowwo; ywqgcegomwaiuquc: return $iewmcsieaqyamggu; } }
