<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac8598d72c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Panel; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function gigwcakmiyayoigw() { } }
