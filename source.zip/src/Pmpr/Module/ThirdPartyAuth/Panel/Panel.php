<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc70e4cb64             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Panel; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function gigwcakmiyayoigw() { } }
