<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb57091d1ec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Model; use Pmpr\Common\Foundation\ORM\DB\Model; use Pmpr\Module\ThirdPartyAuth\Interfaces\CommonInterface; abstract class Common extends Model implements CommonInterface { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $wksoawcgagcgoask = $this->akuociswqmoigkas(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm($wksoawcgagcgoask); } }
