<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8c83fc37             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Model; use Pmpr\Module\ThirdPartyAuth\Container; class Model extends Container { public function aqyikqugcomoqqqi() { UserLink::symcgieuakksimmu(); } }
