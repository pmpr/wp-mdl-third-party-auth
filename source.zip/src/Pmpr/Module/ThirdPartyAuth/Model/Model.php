<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6684012947df3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Model; use Pmpr\Module\ThirdPartyAuth\Container; class Model extends Container { public function aqyikqugcomoqqqi() { UserLink::symcgieuakksimmu(); } }
