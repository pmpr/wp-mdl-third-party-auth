<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce11de8df45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Model; use Pmpr\Module\ThirdPartyAuth\Container; class Model extends Container { public function aqyikqugcomoqqqi() { UserLink::symcgieuakksimmu(); } }
