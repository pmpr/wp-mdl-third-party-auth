<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687085a7134e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\ThirdPartyAuth\Model; use Pmpr\Module\ThirdPartyAuth\Container; class Model extends Container { public function aqyikqugcomoqqqi() { UserLink::symcgieuakksimmu(); } }
