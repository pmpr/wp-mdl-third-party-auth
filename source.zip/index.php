<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6819d6011b31b             |
    |_______________________________________|
*/
 use Pmpr\Module\ThirdPartyAuth\ThirdPartyAuth; ThirdPartyAuth::symcgieuakksimmu();
